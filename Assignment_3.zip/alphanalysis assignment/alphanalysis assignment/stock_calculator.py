import pandas as pd
import yfinance as yf

# Read the CSV file
def read_stocks_csv(url):
    df = pd.read_csv(url)
    return df[['Ticker', 'Weightage']]

# Fetch stock data from Yahoo Finance
def fetch_stock_data(ticker, start_date, end_date):
    # Add '.NS' suffix for NSE stocks
    stock = yf.Ticker(f"{ticker}.NS")
    hist = stock.history(start=start_date, end=end_date)
    return hist['Close']

def calculate_portfolio(investment_amount, start_date, end_date, stocks_url):
    # Read stocks and their weightages
    stocks_df = read_stocks_csv(stocks_url)
    
    # Convert weightages to float
    stocks_df['Weightage'] = stocks_df['Weightage'].astype(float)
    
    # Calculate investment amount for each stock
    stocks_df['Investment'] = stocks_df['Weightage'] * investment_amount
    
    # Initialize results DataFrame with Ticker and Weightage columns
    results = stocks_df[['Ticker', 'Weightage']]
    
    # Fetch historical data for each stock
    for ticker in stocks_df['Ticker']:
        try:
            prices = fetch_stock_data(ticker, start_date, end_date)
            # Calculate shares for each day
            shares = stocks_df[stocks_df['Ticker'] == ticker]['Investment'].values[0] / prices
            # Add each day's shares to results
            for date in prices.index:
                date_str = date.strftime('%Y-%m-%d')
                if date_str not in results.columns:
                    results[date_str] = None
                results.loc[results['Ticker'] == ticker, date_str] = shares[date]
        except Exception as e:
            print(f"Error fetching data for {ticker}: {str(e)}")
    
    return results

# Example usage
stocks_url = "Stocks.csv"
investment_amount = 1000000  # 10 Lakhs
start_date = '2023-04-27'
end_date = '2023-04-28'

# Calculate portfolio
results = calculate_portfolio(investment_amount, start_date, end_date, stocks_url)

# Display results
print("\nPortfolio Allocation (Number of shares):")
print(results)

# Save to Excel
results.to_excel('portfolio_allocation.xlsx', index=False)
print("\nResults have been saved to 'portfolio_allocation.xlsx'")